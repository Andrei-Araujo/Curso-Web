// JavaScript Document
window.onload=function(){
	var btsalvar = document.getElementById('salvar');
	var btler = document.getElementById('ler');
	var btapagar = document.getElementById('apagar');
	
	btsalvar.onclick = salvarNome;
	btler.onclick = lerNome;
	btapagar.onclick = apagarNome;
	
}
function salvarNome(){
	var nome = document.getElementById('nome').value;
	localStorage.setItem('nomeSalvo',nome);
	var span = document.getElementById('mensagem');
	span.innerHTML = "Nome Salvo";
}
function lerNome(){
	
	var nome = localStorage.getItem('nomeSalvo');alert(nome);
	if(nome == null){
		nome = 'Não tem Registro nome';
	}
	var msg = document.getElementById('mensagem');
	msg.innerHTML = "Nome Salvo é " + nome;
}
function apagarNome(){
	var apagar = document.getElementById('apagar');
	localStorage.removeItem('nomeSalvo');
	var msg = document.getElementById('mensagem');
	msg.innerHTML = "Apagado!!!";
}